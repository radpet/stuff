BTB-POS Corpus I

Petya Osenova and Kiril Simov

BulTreeBank Project
Linguistic Modelling Laboratory, CLPP,
Bulgarian Academy of Sciences
Acad. G.Bonchev St. 25A
1113 Sofia, Bulgaria
E-mail: kivs@bgcict.acad.bg
Web: http://www.bultreebank.org/

Here we offer you a small corpus with Bulgarian sentences
marked-up with part of speech information. The sentences are extracted 
from grammar textbooks, dictionary definitions and real texts. 
Each sentence is marked-up with <s> tag, each word with <w> tag 
with two attributes: 'aa' for all possible analyses dividing by semicolons 
and 'ta' for true analysis. Punctuation is marked-up with <pt> tag.

Parts of speech are coded as follows:

Verb = Verb
Noun = Noun
Adj = Adjective
Adv = Adverb
Pron = Pronoun
Prepos = Preposition
Conj = Conjunction
Interj = Interjection
Num = Numeral
Part = Particle

Cyrillic letters are coded with entities according to ISO 8879:1986.

The file btb1posiso.xml contains the corpus. The file btb1pos.dtd
contains a DTD for it.

This corpus was initially developed under the CLaRK Programme
(http://www.sfs.nphil.uni-tuebingen.de/clark/). The same sentences
are marked-up also with morpho-syntactic information and the full
version will be published soon.

Also the corpus is under extension with new sentences within
BulTreeBank Project and will be available on the page of the project.

The corpus is free of charge for research purposes only.
